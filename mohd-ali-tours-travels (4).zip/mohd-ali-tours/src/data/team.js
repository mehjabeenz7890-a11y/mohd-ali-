export const team = [
  { name: 'Mohd Ali', role: 'Director' },
  { name: 'Syed Aslam', role: 'Developer' },
  { name: 'Mohd Hassan', role: 'Senior Documentation' },
  { name: 'Mehjabeen', role: 'Sales Executive' },
  { name: 'Sana', role: 'Sales Executive' }
]
